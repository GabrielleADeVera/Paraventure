﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerProximity : MonoBehaviour {

	public Animator animator;
	public SphereCollider sphereCollider;
	public SimpleCharacterControl simpleCharacterController;
	float aggroMoveSpeed = .66f; //Movespeed when in range of enemy

	// Use this for initialization
	void Start () {
		sphereCollider = GetComponent <SphereCollider>();
		animator = GetComponent<Animator> ();
		simpleCharacterController = GetComponent<SimpleCharacterControl> ();
	}

	void OnTriggerEnter(Collider other){
		if(other.gameObject.CompareTag("Enemy")){
			animator.SetBool("IsAggro", true);
			simpleCharacterController.ChangeMoveSpeed (aggroMoveSpeed,0);


		}
	}

	void OnTriggerExit(Collider other){
		if(other.gameObject.CompareTag("Enemy")){
			animator.SetBool("IsAggro", false);
			simpleCharacterController.ChangeMoveSpeed (1/aggroMoveSpeed,0);

		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
