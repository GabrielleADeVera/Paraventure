﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth : MonoBehaviour {

	public float currentHealth;
	public float startingHealth = 100f;

	// Use this for initialization
	void Start () {
		currentHealth = startingHealth;
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
